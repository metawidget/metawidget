package com.myapp.test;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

public class PerformanceTest
{
	//
	// Public statics
	//

	public static void main( String[] args )
		throws Exception
	{
		long withoutMetawidget = testPerformance( "http://localhost:8080/performance-test/index.faces" );
		long withMetawidget = testPerformance( "http://localhost:8080/performance-test/index2.faces" );
		long difference = ( withMetawidget * 100 / withoutMetawidget );

		// 15% for no fields
		// 75% for single field
		// 150% for all fields

		System.out.println( "Without Metawidget: " + withoutMetawidget / MILLISECONDS_IN_SECOND + " seconds (" + withoutMetawidget / NUMBER_OF_CYCLES + "ms per page)" );
		System.out.println( "With Metawidget: " + withMetawidget / MILLISECONDS_IN_SECOND + " seconds (" + withMetawidget / NUMBER_OF_CYCLES + "ms per page)" );

		if ( difference >= 100 )
			System.out.println( "Difference: " + ( difference - 100 ) + "% slower with Metawidget" );
		else
			System.out.println( "Difference: " + ( 100 - difference ) + "% faster with Metawidget" );
	}

	//
	// Private statics
	//

	private final static int	NUMBER_OF_CYCLES		= 10000;

	private final static float	MILLISECONDS_IN_SECOND	= 1000f;

	private static HttpClient	mClient					= new HttpClient();

	private static long testPerformance( String url )
		throws Exception
	{
		long startTime = System.currentTimeMillis();

		for ( int loop = 0; loop < NUMBER_OF_CYCLES; loop++ )
		{
			GetMethod methodReport = new GetMethod( url );

			try
			{
				mClient.executeMethod( methodReport );
			}
			finally
			{
				methodReport.releaseConnection();
			}
		}

		return System.currentTimeMillis() - startTime;
	}
}
