package com.myapp.model;

import org.metawidget.inspector.annotation.UiComesAfter;
import org.metawidget.inspector.annotation.UiLarge;
import org.metawidget.inspector.annotation.UiLookup;
import org.metawidget.inspector.annotation.UiSection;

public class Person
{
	private String	mTitle;

	private String	mName;

	private int		mAge;

	private boolean	mRetired;

	private String	mNotes;

	//
	// Public methods
	//

	@UiLookup( { "Mr", "Mrs", "Miss" } )
	public String getTitle()
	{
		return mTitle;
	}

	public void setTitle( String title )
	{
		mTitle = title;
	}

	@UiComesAfter( "title" )
	public String getName()
	{
		return mName;
	}

	public void setName( String name )
	{
		mName = name;
	}

	@UiComesAfter( "name" )
	public int getAge()
	{
		return mAge;
	}

	public void setAge( int age )
	{
		mAge = age;
	}

	@UiComesAfter( "age" )
	public boolean isRetired()
	{
		return mRetired;
	}

	public void setRetired( boolean retired )
	{
		mRetired = retired;
	}

	@UiComesAfter( "retired" )
	@UiLarge
	@UiSection( "Notes" )
	public String getNotes()
	{
		return mNotes;
	}

	public void setNotes( String notes )
	{
		mNotes = notes;
	}
}
